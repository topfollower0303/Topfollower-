document.getElementById("orderForm").addEventListener("submit", function (e) {
    e.preventDefault();
    
    const platform = document.getElementById("platform").value;
    const link = document.getElementById("link").value;
    const quantity = document.getElementById("quantity").value;
    const amount = document.getElementById("amount").value;

    if (platform && link && quantity && amount) {
        alert("Order placed successfully!\nPlatform: " + platform + "\nLink: " + link + "\nQuantity: " + quantity + "\nAmount: ₹" + amount);
    } else {
        alert("Please fill out all fields!");
    }
});